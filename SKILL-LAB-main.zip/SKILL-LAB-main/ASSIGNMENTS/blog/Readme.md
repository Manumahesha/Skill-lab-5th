step 1: frok this repository</br>
step 2: clone this into system</br>
step 3: navigate to ur folder blog</br>
    Ex : cd SKILL-LAB/ASSIGENMENTS/Blogs</br>
step 4: run command "npm install" </br>
step 5: replace mongoose URl</br>
step 6: run server " nodemon start"</br>
step 7: using postman to verify the End points</br>